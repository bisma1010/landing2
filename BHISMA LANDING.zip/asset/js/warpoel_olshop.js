$(document).ready(function(e) {
	// ------------- User Interface Admin Page	
	$('.table_produk .row_produk').on('click', function(spesifik_obj) {
		var obj_target = $(this);
		var check_produk = obj_target.find('.check_product');
		if ( !$(spesifik_obj.target).is(check_produk) ) {
			//JIka yang diklik bukan checkboxnya, maka check checkboxnya tersebut
			check_produk.click();
		}
	});
	$('#add_product_form').on('submit', function(e) {
		/* Jadi kita akan memvalidasi setiap file input pada form melalui parentnya
		- Jika suatu parent pada input file  tersebut punya class bernama .active_upload, Maka tandanya file tersebut ada isinya 
		- Tapi jika parent pada input file tersebut tidak punya class bernama .active_upload, Maka tandanya file tersebut tidak ada isinya dan tidak akan di kirim dengan menghapus input filenya
		*/


		var form = $(this);
		var col_frame = form.find('.col_frame');
		//Hitung dan validasi input file tidak boleh kosong, ( minimal 1 terisi ) dengan menghitung elemen .col_frame dengan class .active_upload 
		var col_frame_active = col_frame.filter('.active_upload');
		if ( col_frame_active.length > 0 ) {
			// Jika file input sudah ada yang di isi, maka hapus inputan file yang tidak ada isinya	atau file input yang parent .col_frame nya tidak punya class active_upload
			col_frame.not('.active_upload').find('input[type=file]').remove();
			return true;
		}else{
			alert('Upload minimal 1 foto produk');
		}

		
		return false;
	});

	// Ketika checkbox product di halaman admin
	$('.check_product').on('change', function(e) {
		// Check semua checkbox produk yang dipilih
		var check_produk = $('.check_product:checked').length;
		if ( check_produk > 0) {
			// Jika ada produk yang di centang
			$('#btn_delete').prop('disabled', false);
		}else{
			// Jika ada produk yang di centang
			$('#btn_delete').prop('disabled', true);
		}
	});
	// Tombol ubah untuk mengubah form profile info di dashboard info profile
	$('#btn_ubah').on('click', function(e) {
		var btn = $(this);
		var form = btn.parents('form');
		// AKtifkan semua inputnya
		form.find('input').not('input[type=email]').prop('readonly', false);
		// Disbale di properti
		form.find('input[type=file]').prop('disabled', false);
		// Disable di class bootstrao
		form.find('button[type=submit]').removeClass('disabled');
	});
	// Upload Image Admin Dashboard profile
	$('.input_img_profile').find('input[type=file]').on('change', function( files) {
		upload_img_profile( this, files );
	});
	// Upload Image Frame
	$('.col_frame').find('input[type=file]').on('change', function( files) {
		upload_img_produk( this, files );
	});

	// ------------- End Of User Interface Admin Page

	//------ User Interface product
	$('#sort_form').find('select').on('change', function(e) {
		// Set Value Input Berdasarkan nama #id pada masing masing option
		var select_input = $(this);
		var option_selected = select_input.find('option').filter(':selected');
		var set_value_id = option_selected.attr('id');
		// Ubah nilai value dari option yang dipilih berdarkan dari id punya elemen option tersebut
		option_selected.val( set_value_id );

		$(this).parents('form').submit();
	});


	// ----------- User Interface view product
	$('.col_img').on('click', function(e ) {
		img_viewer_product(this);
	});
	$('.col_img').first().click();
});

function img_viewer_product(col_img) {
	// Ambil source url img
	col_img = $(col_img);
	var src_img = col_img.find('img').attr('src');
	// Terapkan sourcenya ke img view
	var frame_img_view = $('.img_view').find('img');
	frame_img_view.attr( 'src', src_img );
	//Berikan efect tanda active ke indicator
	$('.col_img').removeClass('active');
	col_img.addClass('active');
}
function upload_img_profile(obj, dataFile) {
	var inputUpload = $(obj);
	//Methode untuk mengambil dan membuat link source file 
	var file = dataFile.target.files[0]; 
	var fileSrc = URL.createObjectURL(file);
	//Menampilkan gambar di frame elemen dan hilangkan efek border
	var input_img_profile = inputUpload.parents('.input_img_profile');
	var frame = input_img_profile.find('.frame').find('img');
	frame.attr('src', fileSrc);	
}
function upload_img_produk(obj, dataFile) {
	var inputUpload = $(obj);
	//Methode untuk mengambil dan membuat link source file 
	var file = dataFile.target.files[0]; 
	var fileSrc = URL.createObjectURL(file);
	//Menampilkan gambar di frame elemen dan hilangkan efek border
	var col_frame = inputUpload.parents('.col_frame');
	var frame = col_frame.find('.frame');
	var el_frame = '<img src="'+fileSrc+'">';
	frame.html(el_frame);
	col_frame.css('border', 'none');

	//Tambahkan ke elemen .col_frame suatu class untuk menandakan input file tersebut sudah terisi
	col_frame.addClass('active_upload');
}
function sidebar_menu_active( id_sidebar_menu, id_sidebar_sub_menu = "") {
	// Liat di id sidebar menu di sidebar content
	$('.list_link').removeClass('active');


	var target_list = $('.list_link').filter(id_sidebar_menu);
	var list_drop = target_list.parents('.list_drop');	
	// Cek apakah list yang dipilih itu punya list menu atau tidak dengan melihat apakah list tersebut punya parent dengan class .list_drop
	if ( list_drop.length > 0 ) {
		// Jika listnya punya sub list, maka buka drop_list_sub nya dan aktifkan sub list_link yang dipilih yang ada didalam drop_list_sub
		list_drop.addClass('active');
		// Cek sub list_link yang dipilih
		var target_list_sub;
		if ( id_sidebar_sub_menu.length > 0 ) {
			// Jika ada sub list yang dipilih
			target_list_sub = $('.list_link').filter(id_sidebar_sub_menu);
		}else{
			// Jika tidak ada sub list yang dipilih, maka pilih sub list_link dengan index pertama di .drop_list_sub
			target_list_sub = list_drop.find('.drop_list_sub').find('.list_link').first();
		}
		target_list_sub.addClass('active');
	}else{
		// Jika listnya tidak punya sub list, maka aktifkan langsung list_link nya
		target_list.addClass('active');
	}
}