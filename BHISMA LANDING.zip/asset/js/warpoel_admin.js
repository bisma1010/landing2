$(document).ready(function(e) {
	$('.dropdown_item').find('a.nav-link, button').on('click', function(e) {
		var dropdown_content = $(this).parent().find('.yt_dropdown');
		dropdown_content.show(100, function() {
			$(window).bind('click', function(event) {
				// event adalah object dari lingkungan detail object yang dipilih
				// yt_dropdown yang dipilih adalah yang 1 parent dengan tombolnya
				drop_outside(event, dropdown_content);
			});
		});	
	});
	$('.btn_sidebar').on('click', function(e) {	
		content_sidebar(this);
	});
});
function content_sidebar(btn) {
	// Note : atribut data-target-sidebar bisa selector class ataupun id di elemen selector css yang ada di content sidebar
	btn = $(btn);
	var sidebar;
	if ( btn.attr("data-target-sidebar") ) {
		var data_target_sidebar = btn.attr('data-target-sidebar');
		sidebar = $(data_target_sidebar);
	}else{
		//Sidebar default
		sidebar = $('.content_sidebar');
	}
	// Jika tombol close sidebar yang di pencet ( ada didalam sidebar )
	if ( btn.parents('.content_sidebar').is('.content_sidebar') ) {
		sidebar = btn.parents('.content_sidebar');
	}

	// Cek apakah side bar terbuka atau tertutup
	if ( sidebar.is(':visible') ) {
		// Jika sidebar Terbuka, Tutup sidebar
		sidebar.hide('drop', 100);		
	}else{
		// Jika sidebar tertutup, Buka sidebar
		sidebar.show('drop', 100);
	}
}
function drop_outside(obj, dropdown_content) {
	// Jika user klik di luar elemen dropdown, maka dropdown akan hilang
	// is() bisa digunakan untuk memeriksa suatu object
	var target = $(obj.target);
	if ( !target.is(dropdown_content.find('*')) ) {
		$(window).unbind('click');
		$(dropdown_content).hide(100);
	}
}

